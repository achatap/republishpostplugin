<?php
/**
 * Plugin Name: Anurag Old Posts v3
 * Plugin URI: https://yourwebsite.com/delete-and-republish-old-posts
 * Description: This plugin deletes old posts and republishes them as new posts automatically.
 * Version: 1.0
 * Author: Your Name
 * Author URI: https://yourwebsite.com
 * License: GPLv2 or later
 */

 function delete_and_republish_old_posts() {
    // Define the number of days after which the post should be deleted and republished
    $days = 90;

    // Get all the posts that are older than $days
    $args = array(
        'post_type'      => 'post',
        'post_status'    => 'publish',
        'date_query'     => array(
            array(
                'column' => 'post_date_gmt',
                'before' => $days . ' days ago',
            ),
        ),
        'posts_per_page' => 1,
        'order'          => 'ASC',
        'orderby'        => 'date'
    );
    $old_posts = get_posts( $args );

    // If there are no old posts, return
    if (empty($old_posts)) {
        return;
    }

    // Loop through each old post
    foreach ( $old_posts as $old_post ) {
		
		// Get the tags from the old post
        $tags = wp_get_post_tags($old_post->ID, array('fields' => 'names'));
		
		// If there are no tags, use the post title as a tag
		if (empty($tags)) {
			$tags = array($old_post->post_title);
		}
		
		// Remove unwanted words from tags
        $tags = array_map(function($tag) {
            return str_ireplace(array('{Updated}', 'Updated', 'Top 10', '{Guide & Reviews}', 'in detail'), '', $tag);
        }, $tags);
		
		// Remove empty tags
		$tags = array_filter($tags);
		
		
		
          // Delete the old post
		wp_delete_post( $old_post->ID, true );
		

        // Create a new post with the same content as the old post
		$new_post = array(
			'post_title'    => $old_post->post_title,
			'post_content'  => $old_post->post_content,
			'post_status'   => 'publish',
			'post_type'     => 'post',
			'post_author'   => $old_post->post_author,
			'post_category' => array( $old_post->post_category[0] ),
			'tags_input'    => implode(',', $tags)
		);
		
		$new_post_id = wp_insert_post( $new_post );
		
        
        // Add the tags to the new post
        wp_set_post_tags($new_post_id, $tags);
		
		sleep(30);

	}
		
	
}


function schedule_delete_and_republish_old_posts() {
    if (!wp_next_scheduled('delete_and_republish_old_posts')) {
        wp_schedule_single_event(time() + 60, 'delete_and_republish_old_posts');
    }
}
add_action('wp', 'schedule_delete_and_republish_old_posts');

add_action('delete_and_republish_old_posts', 'delete_and_republish_old_posts');



?>

